from . import my_fire_smoke_dataset # Register MyDataset

ds = tfds.load('my_fire_smoke_dataset')  # MyDataset available