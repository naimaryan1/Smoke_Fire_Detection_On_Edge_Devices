"""my_fire_smoke_dataset dataset."""

from . import my_fire_smoke_dataset
import tensorflow_datasets as tfds

class MyFireSmokeDatasetTest(tfds.testing.DatasetBuilderTestCase):
  """Tests for my_fire_smoke_dataset dataset."""
  # TODO(my_fire_smoke_dataset):
  DATASET_CLASS = my_fire_smoke_dataset.Builder
  SPLITS = {
      'train': 3,  # Number of fake train example
      'test': 1,  # Number of fake test example
  }

  # If you are calling `download/download_and_extract` with a dict, like:
  #   dl_manager.download({'some_key': 'http://a.org/out.txt', ...})
  # then the tests needs to provide the fake output paths relative to the
  # fake data directory
  # DL_EXTRACT_RESULT = {'some_key': 'output_file1.txt', ...}


if __name__ == '__main__':
  tfds.testing.test_main()
