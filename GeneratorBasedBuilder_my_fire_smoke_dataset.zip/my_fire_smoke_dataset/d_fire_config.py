import tensorflow_datasets as tfds

class DFireConfig(tfds.core.BuilderConfig):
  image_size_1 = (640,640)
  image_size_2 = (320,320)
  image_size_3 = (160,160)