
"""my_fire_smoke_dataset dataset."""
import os
import numpy as np 
from numpy import bool_ as np_bool
import tensorflow_datasets as tfds
from tensorflow import data as tf_data
import tensorflow_datasets as tfds
import tensorflow as tf
from d_fire_config import DFireConfig
from PIL import Image

#Author: Ary Naim (anaim.unm.edu)
#Reference guide: https://www.tensorflow.org/datasets/add_dataset
#Adapted based on VOC example:https://github.com/chasojeong/bbox_dataset/blob/master/tensorflow_datasets/object_detection/voc.py
#execute the command "tfds build --register_checksums" after makeing any changes to this Python code 

class MyFireSmokeDataset(tfds.core.GeneratorBasedBuilder):
  """DatasetBuilder for my_fire_smoke_dataset dataset."""

  MANUAL_DOWNLOAD_INSTRUCTIONS = """
  Data is in <YOUR_PATH>/Smoke_and_Fire_Datasets/D-Fire
  """

  DATA_PATH = "/content/gdrive/MyDrive/Smoke_and_Fire_Datasets/D-Fire"
  VERSION = tfds.core.Version('1.0.0')
  RELEASE_NOTES = {
      '1.0.0': 'Initial release.',
      }

  class_ids = ("Fire", "Smoke",)
  
  _DESCRIPTION = """
  D-Fire is an image dataset of fire and smoke occurrences designed for machine learning and object detection algorithms with more than 21,000 images.
  References: https://github.com/gaiasd/DFireDataset"""

  """
  function: _info(self)
  Input: None
  Output: tfds.core.DatasetInfo
  Description: 
  Returns tfds.core.DatasetInfo which is the class that describes our 
  dataset.  
  """
  def _info(self):
      return tfds.core.DatasetInfo(
          builder=self,
          description=self._DESCRIPTION,
          features=tfds.features.FeaturesDict({
              "image": tfds.features.Image(),
              "image/filename": tfds.features.Text(),
              "objects": tfds.features.Sequence({
                  "label": tfds.features.ClassLabel(names=self.class_ids),
                  "bbox": tfds.features.BBoxFeature(),
                  "is_truncated": np_bool,
                  "is_difficult": np_bool,
              }),
              "labels": tfds.features.Sequence(
                  tfds.features.ClassLabel(names=self.class_ids)
              ),
              "labels_no_difficult": tfds.features.Sequence(
                  tfds.features.ClassLabel(names=self.class_ids)
              ),
          }),
          homepage="https://github.com/gaiasd/DFireDataset",
          citation="""Pedro Vinícius Almeida Borges de Venâncio, 
          Adriano Chaves Lisboa, Adriano Vilela Barbosa: 
          An automatic fire detection system based on deep 
          convolutional neural networks for low-power, 
          resource-constrained devices. 
          In: Neural Computing and Applications, 2022""",
      )

  def _split_generators(self, dl_manager: tfds.download.DownloadManager):
    """Returns SplitGenerators."""
    extracted_path = (self.DATA_PATH)
    return {
      'train': self._generate_examples(
          images_path=str(extracted_path)+str("/train/images"),
          labels_path=str(extracted_path)+("/train/labels"),
      ),
      'test': self._generate_examples(
          images_path=str(extracted_path)+str("/test/images"),
          labels_path=str(extracted_path)+("/test/labels"),
      ),
  }

  def _generate_examples(self, images_path,labels_path):
      """Yields examples."""
      image_files = []
      labels_files = []
      # Yields (key, example) tuples from the dataset
      #1) step 1 - get images & labels (which have class & bounding boxes ) 
      image_files = self.get_jpeg_files(images_path)
      labels_files = self.get_txt_files(labels_path)
      image_files = image_files[0:500]
      labels_files = labels_files[0:500]
      #2) for each image & label get the files 
      for img_f, lbl_f in zip(image_files,labels_files):
        #return the image bytes & bounding bix info
        filename = os.path.basename(img_f)
        image, bounding_boxes = self.load_image_bounding_box(img_f,lbl_f,DFireConfig.image_size_1)
        if bounding_boxes is not None:
          print("_generate_examples(), DATA:",bounding_boxes)
          yield filename, self._generate_example(img_f,bounding_boxes,bounding_boxes["class"])
        else:
          continue

  
  def _generate_example(self,image_filepath,bbox,label):
    objects = []
    labels = []
    labels_no_difficult = []
    label = bbox["class"]
    x = bbox["x"]
    y = bbox["y"]
    w = bbox["width"]
    h = bbox["height"]
    #convert from YOLO to relative BBox 
    image_w, image_h = self.get_image_dimensions(image_filepath)
    yolo_box = (x,y,w,h)
    pixel_coords = self.yolo2pixel((image_w, image_h),[x,y,w,h])
    x1 = pixel_coords[0]/image_w
    y1 = pixel_coords[1]/image_h
    x2 = pixel_coords[2]/image_w
    y2 = pixel_coords[3]/image_h
    if x2 > 1:
      x2 = 1.0
    if y2 > 1:
      y2 = 1.0
    if label == "0":
      label = self.class_ids[0]
    if label == "1":
      label = self.class_ids[1]
      #References: https://www.tensorflow.org/datasets/api_docs/python/tfds/features/BBox
    objects.append({
          "label": label,
          "bbox": tfds.features.BBox(x1,y1,x2,y2),
          "is_truncated": False,
          "is_difficult": False,
      })
    return {
        "image": image_filepath,
        "image/filename": os.path.basename(image_filepath),
        "objects": objects,
        "labels": np.array([label]),
        "labels_no_difficult": labels_no_difficult,
    }

  """
  HELPER FUNCTIONS - START 
  that are meant to conver the Darkent YOLO
  parse the Darket YOLO structure 
  ./train/images ./train/label & ./test/label ./test/images

  """
    #References: https://github.com/gaiasd/DFireDataset/blob/master/utils/utils.py
  def non_negative(self,coord):
    
    """
        Sets negative coordinates to zero. This fixes bugs in some labeling tools.
        
        Input:
            coord: Int or float
            Any number that represents a coordinate, whether normalized or not.
    """
    
    if coord < 0:
        return 0
    else:
        return coord

  #References: https://github.com/gaiasd/DFireDataset/blob/master/utils/utils.py
  def yolo2pixel(self,dim, yolo_coords):
    
    """
        Transforms coordinates in YOLO format to coordinates in pixels.
        
        Input:
            dim: Tuple or list
            Image size (width, height).
            yolo_coords: List
            Bounding box coordinates in YOLO format (xcenter, ycenter, width, height).
        Output:
            pixel_coords: List
            Bounding box coordinates in pixels (xmin, ymin, xmax, ymax).
    """
    
    xmin = self.non_negative(round(dim[0] * (yolo_coords[0] - yolo_coords[2]/2)))
    xmax = self.non_negative(round(dim[0] * (yolo_coords[0] + yolo_coords[2]/2)))
    ymin = self.non_negative(round(dim[1] * (yolo_coords[1] - yolo_coords[3]/2)))
    ymax = self.non_negative(round(dim[1] * (yolo_coords[1] + yolo_coords[3]/2)))
    
    pixel_coords = [xmin, ymin, xmax, ymax]
    return pixel_coords

  
  def pixel2yolo(self,dim, pixel_coords):
    
    """
        Transforms coordinates in YOLO format to coordinates in pixels.
        
        Input:
            dim: Tuple or list
            Image size (width, height).
            pixel_coords: List
            Bounding box coordinates in pixels (xmin, ymin, xmax, ymax).
        Output:
            yolo_coords: List
            Bounding box coordinates in YOLO format (xcenter, ycenter, width, height).
    """
    
    dw = 1/dim[0]
    dh = 1/dim[1]
    xcenter = self.non_negative(dw*(pixel_coords[0] + pixel_coords[2])/2)
    ycenter = self.non_negative(dh*(pixel_coords[1] + pixel_coords[3])/2)
    width = self.non_negative(dw*(pixel_coords[2] - pixel_coords[0]))
    height = self.non_negative(dh*(pixel_coords[3] - pixel_coords[1]))
    
    yolo_coords = [xcenter, ycenter, width, height]
    print("yolo_coords:",yolo_coords)
    return yolo_coords
  
  def get_image_dimensions(self,image_path):
    try:
        with Image.open(image_path) as img:
            width, height = img.size
            return width, height
    except IOError:
        print("Unable to open image:", image_path)
        return None

  def get_jpeg_files(self,path):
    jpeg_files = []
    for file in os.listdir(path):
        if file.endswith(".jpg") or file.endswith(".jpeg"):
            jpeg_files.append(os.path.join(path, file))
    return jpeg_files

  def get_txt_files(self,path):
      txt_files = []
      for file in os.listdir(path):
          if file.endswith(".txt"):
            txt_files.append(os.path.join(path, file))
      return txt_files

  # Create a function to read the bounding boxes from a text file
  def read_bounding_box(self,label_file):
    #print("read_bounding_boxes - START")
    with open(label_file, 'r') as f:
      for line in f:
        if not line.strip():
          # Empty line, set class to 0 and bounding box to 0,0,0,0
          return {
              'class': "None",
              'x': 0.0,
              'y': 0.0,
              'width': 0.0,
              'height': 0.0
          }
        else:
          class_name, x, y, w, h = line.split()
          if class_name == "0":
            class_name= self.class_ids[0]
          if class_name == "1":
            class_name= self.class_ids[1]
          return {
              'class': class_name,
              'x': float(x),
              'y': float(y),
              'width': float(w),
              'height': float(h),
          }
    #print("read_bounding_boxes - END")


  def load_image_bounding_box(self,image_file, label_file, image_size):
    """
    Load an image and its corresponding bounding box, resize the image.

    Parameters:
    - image_file (str): Path to the image file to be loaded.
    - image_size (tuple): Desired size to which the image will be resized (width, height).

    Returns:
    - resized_image (tf.Tensor): The resized image as a TensorFlow tensor.
    - bounding_box (list or dict): The bounding box coordinates loaded from the label file.
    """
    #print("load_image_and_bounding_boxes - START")
    image = tf.io.read_file(image_file)
    #Decode a JPEG-encoded image to a uint8 tensor.
    image_tensor = tf.image.decode_jpeg(image)
    #https://www.tensorflow.org/api_docs/python/tf/image/resize_with_pad
    #Resizes an image to a target width and height by keeping the aspect ratio the same without distortion.
    resized_image = tf.image.resize_with_pad(
    image_tensor,
    image_size[1],
    image_size[0],
    method='bilinear',
    antialias=False
    )
    bounding_box = self.read_bounding_box(label_file)
    #print("load_image_and_bounding_boxes - END")
    print("bounding_box:",bounding_box)
    return resized_image, bounding_box

  """
  Helper functions - END
  """     
